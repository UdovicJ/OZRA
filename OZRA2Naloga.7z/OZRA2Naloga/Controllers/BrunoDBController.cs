﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OZRA2Naloga.Services;
using OZRA2Naloga.Models;

namespace OZRA2Naloga.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrunoDBController: ControllerBase
    {
        private readonly BrunoService _brunoService;

        public BrunoDBController(BrunoService brunoService)
        {
            _brunoService = brunoService;
        }

        [HttpGet]
        public ActionResult<List<Tekmovalec>> Get() =>
            _brunoService.Get();

        [HttpGet("{id:length(24)}", Name = "GetBook")]
        public ActionResult<Tekmovalec> Get(string id)
        {
            var tekmovalec = _brunoService.Get(id);

            if (tekmovalec == null)
            {
                return NotFound();
            }

            return tekmovalec;
        }

        [HttpPost]
        public ActionResult<Tekmovalec> Create(Tekmovalec tekmovalec)
        {
            _brunoService.Create(tekmovalec);

            return CreatedAtRoute("GetBook", new { id = tekmovalec.Id.ToString() }, tekmovalec);
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Tekmovalec tekmovalecIn)
        {
            var book = _brunoService.Get(id);

            if (book == null)
            {
                return NotFound();
            }

            _brunoService.Update(id, tekmovalecIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var tekmovalec = _brunoService.Get(id);

            if (tekmovalec == null)
            {
                return NotFound();
            }

            _brunoService.Remove(tekmovalec.Id);

            return NoContent();
        }
    }
}