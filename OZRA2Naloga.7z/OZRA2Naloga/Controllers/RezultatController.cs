﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OZRA2Naloga.Services;
using OZRA2Naloga.Models;

namespace OZRA2Naloga.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RezultatController : ControllerBase
    {
        private readonly RezultatService _rezultatService;

        public RezultatController(RezultatService rezultatService)
        {
            _rezultatService = rezultatService;
        }

        [HttpGet]
        public ActionResult<List<Rezultat>> Get() =>
            _rezultatService.Get();

        [HttpGet("{id:length(24)}", Name = "GetRezultat")]
        public ActionResult<Rezultat> Get(string id)
        {
            var rezultat = _rezultatService.Get(id);

            if (rezultat == null)
            {
                return NotFound();
            }

            return rezultat;
        }

        [HttpPost]
        public ActionResult<Rezultat> Create(Rezultat rezultat)
        {
            _rezultatService.Create(rezultat);

            return CreatedAtRoute("GetRezultat", new { id = rezultat.Id.ToString() }, rezultat);
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Rezultat rezultatIn)
        {
            var rezultat = _rezultatService.Get(id);

            if (rezultat == null)
            {
                return NotFound();
            }

            _rezultatService.Update(id, rezultatIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var rezultat = _rezultatService.Get(id);

            if (rezultat == null)
            {
                return NotFound();
            }

            _rezultatService.Remove(rezultat.Id);

            return NoContent();
        }
    }
}
