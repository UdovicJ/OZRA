﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using Newtonsoft.Json;
using MongoDB.Bson.Serialization.Attributes;

namespace OZRA2Naloga.Models
{
    public class Rezultat
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public string genderRank { get; set; }
        public string divRank { get; set; }
        public string overallRank { get; set; }
        public string bib { get; set; }
        public string division { get; set; }
        public string points { get; set; }
        public string swim { get; set; }
        public string swimDistance { get; set; }
        public string t1 { get; set; }
        public string bike { get; set; }
        public string bikeDistance { get; set; }
        public string t2 { get; set; }
        public string run { get; set; }
        public string runDistance { get; set; }
        public string overall { get; set; }
        public string tekma { get; set; }
    }
}
