﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace OZRA2Naloga.Models
{
    public class RezultatDatabaseSettings : IRezultatDatabaseSettings
    {
        public string RezultatCollectionName { get; set; }
        public string ConnectionString1 { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IRezultatDatabaseSettings
    {
        string RezultatCollectionName { get; set; }
        string ConnectionString1 { get; set; }
        string DatabaseName { get; set; }
    }
}
