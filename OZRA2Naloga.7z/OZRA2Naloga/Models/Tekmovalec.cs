﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using Newtonsoft.Json;
using MongoDB.Bson.Serialization.Attributes;

namespace OZRA2Naloga.Models
{
    public class Tekmovalec
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        //[BsonElement("Name")]
        //[JsonProperty("Name")]
        public string name { get; set; }
        public string age { get; set; }
        public string country { get; set; }
        public string profession { get; set; }
        
    }
}
