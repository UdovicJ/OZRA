﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OZRA2Naloga.Models;

namespace OZRA2Naloga.Services
{
    public class BrunoService
    {
        private readonly IMongoCollection<Tekmovalec> _tekmovalec;

        public BrunoService(IBrunoDBDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            try
            {
                _tekmovalec = database.GetCollection<Tekmovalec>(settings.BrunoDBCollectionName);
            }
            catch
            { }
        }
       
        public List<Tekmovalec> Get() =>
            _tekmovalec.Find(tekmovalec => true).ToList();
    

        public Tekmovalec Get(string id) =>
            _tekmovalec.Find<Tekmovalec>(Tekmovalec=> Tekmovalec.Id == id).FirstOrDefault();

        public Tekmovalec Create(Tekmovalec tekmovalec)
        {
            _tekmovalec.InsertOne(tekmovalec);
            return tekmovalec;
        }

        public void Update(string id, Tekmovalec tekmovalecIn) =>
            _tekmovalec.ReplaceOne(Tekmovalec => Tekmovalec.Id == id, tekmovalecIn);

        public void Remove(Tekmovalec tekmovalecIn) =>
            _tekmovalec.DeleteOne(Tekmovalec => Tekmovalec.Id == tekmovalecIn.Id);

        public void Remove(string id) =>
            _tekmovalec.DeleteOne(Tekmovalec => Tekmovalec.Id == id);
    }
}
