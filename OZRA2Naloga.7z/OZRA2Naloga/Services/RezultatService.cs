﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OZRA2Naloga.Models;


namespace OZRA2Naloga.Services
{
    public class RezultatService
    {
        private readonly IMongoCollection<Rezultat> _rezultat;

        public RezultatService(IRezultatDatabaseSettings settings)
        {
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("BrunoDB");
            try
            {
                _rezultat = database.GetCollection<Rezultat>("Rezultat");
            }
            catch
            { }
        }

        public List<Rezultat> Get() =>
            _rezultat.Find(rezultat => true).ToList();


        public Rezultat Get(string id) =>
            _rezultat.Find<Rezultat>(Rezultat => Rezultat.Id == id).FirstOrDefault();

        public Rezultat Create(Rezultat rezultat)
        {
            _rezultat.InsertOne(rezultat);
            return rezultat;
        }

        public void Update(string id, Rezultat rezultatIn) =>
            _rezultat.ReplaceOne(rezultat => rezultat.Id == id, rezultatIn);

        public void Remove(Rezultat rezultatIn) =>
            _rezultat.DeleteOne(rezultat => rezultat.Id == rezultatIn.Id);

        public void Remove(string id) =>
            _rezultat.DeleteOne(rezultat => rezultat.Id == id);
    }
}
